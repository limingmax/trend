from zutils.task.task_redis import TaskRedis
class TaskMultiTemplate:
    def run(self, task_redis, task):
        return

    def task_name(self):
        return 'taskname'