class TaskSingleTemplate:
    def __init__(self, sess, conf):
        self.sess = sess
        self.conf = conf
        self.init()

    def init(self):
        pass

    def run(self, task):
        pass
